/* ===== بناء الصفحة انطلاقاً من data.js ===== */
const $ = id => document.getElementById(id);
const card = (ic, t, s, d) => `<div class="card"><div class="ic">${ic}</div><h3>${t}</h3>${s ? `<small>${s}</small>` : ""}<p>${d}</p></div>`;

$("unitsGrid").innerHTML = SITE.sections.map(s => card(s.icon, s.name, s.age, s.desc)).join("");
$("actGrid").innerHTML = SITE.activities.map(a => card(a.icon, a.title, "", a.desc)).join("");
$("newsGrid").innerHTML = SITE.news.map(n =>
  card("📰", n.title, new Date(n.date).toLocaleDateString("ar-TN"), n.text)).join("");
$("galGrid").innerHTML = SITE.gallery.map((g, i) =>
  `<div class="gi" data-i="${i}">${g.type === "photo" ? `<img src="${g.src}" alt="${g.caption}" loading="lazy" onerror="this.remove()">` : ""}${g.type === "video" ? "<i>▶</i>" : ""}<span>${g.caption}</span></div>`).join("");

const c = SITE.contact;
$("info").innerHTML = `<li>📍 ${c.address}</li><li>✉️ ${c.email}</li><li>📞 <span dir="ltr">${c.phone}</span></li>`;
$("fb").href = SITE.social.facebook; $("ig").href = SITE.social.instagram;

/* القائمة على الهاتف */
$("burger").onclick = () => $("menu").classList.toggle("open");
$("menu").onclick = () => $("menu").classList.remove("open");

/* حركات التمرير */
const io = new IntersectionObserver(es => es.forEach(e => e.isIntersecting && (e.target.classList.add("show"), io.unobserve(e.target))), { threshold: .12 });
document.querySelectorAll(".reveal,.card,.gi").forEach(el => io.observe(el));

/* تمييز الرابط النشط */
const links = [...document.querySelectorAll("#menu a,.dock a")];
addEventListener("scroll", () => {
  let cur = "home";
  document.querySelectorAll("section[id]").forEach(s => { if (scrollY >= s.offsetTop - 120) cur = s.id; });
  links.forEach(a => a.classList.toggle("on", a.hash === "#" + cur));
});

/* تكبير الصور والفيديو */
$("galGrid").onclick = e => {
  const it = e.target.closest(".gi"); if (!it) return;
  const g = SITE.gallery[it.dataset.i];
  $("lbc").innerHTML = g.type === "video" ? `<iframe src="${g.src}" allowfullscreen></iframe>` : `<img src="${g.src}" alt="${g.caption}">`;
  $("lb").classList.add("open");
};
const closeLb = () => { $("lb").classList.remove("open"); $("lbc").innerHTML = ""; };
$("lbx").onclick = closeLb; $("lb").onclick = e => e.target.id === "lb" && closeLb();
addEventListener("keydown", e => e.key === "Escape" && closeLb());

/* نموذج الاتصال: Formspree إن وُجد، وإلا فتح البريد الإلكتروني */
$("form").onsubmit = async e => {
  e.preventDefault();
  const f = new FormData(e.target), st = $("status");
  if (SITE.formEndpoint) {
    const r = await fetch(SITE.formEndpoint, { method: "POST", body: f, headers: { Accept: "application/json" } });
    st.textContent = r.ok ? "تم إرسال رسالتك، شكراً!" : "حدث خطأ، حاول مجدداً.";
    if (r.ok) e.target.reset();
  } else {
    location.href = `mailto:${c.email}?subject=${encodeURIComponent("رسالة من " + f.get("name"))}&body=${encodeURIComponent(f.get("msg") + "\n\n" + f.get("email"))}`;
  }
};

/* Progress bar + header style on scroll */
addEventListener("scroll", () => {
  $("bar").style.width = scrollY / (document.documentElement.scrollHeight - innerHeight) * 100 + "%";
  $("nav").classList.toggle("sc", scrollY > 40);
}, { passive: true });

/* Stagger delay for cards and gallery items */
document.querySelectorAll(".card,.gi").forEach((el, i) => el.style.transitionDelay = (i % 4) * 90 + "ms");

/* Animated counters */
const co = new IntersectionObserver(es => es.forEach(e => {
  if (!e.isIntersecting) return; co.unobserve(e.target);
  const b = e.target, n = +b.dataset.n, t0 = performance.now();
  (function step(t) { const k = Math.min((t - t0) / 1600, 1); b.textContent = (b.dataset.p || "") + Math.round(n * k); k < 1 && requestAnimationFrame(step); })(t0);
}), { threshold: .6 });
document.querySelectorAll("[data-n]").forEach(b => co.observe(b));
